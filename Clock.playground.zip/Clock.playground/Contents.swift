import UIKit

var Hours = 0
var Minutes = 0
var Seconds = 0

while (true){
    for Hours in 0...23{
        for Minutes in 0...59{
            for Seconds in 0...59{
                sleep(1)
                print(Hours,Minutes,Seconds)
            }
            Seconds = 0
        }
        Minutes = 0
    }
    Hours = 0
}
